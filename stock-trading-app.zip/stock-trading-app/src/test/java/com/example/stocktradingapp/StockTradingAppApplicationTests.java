package com.example.stocktradingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockTradingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
